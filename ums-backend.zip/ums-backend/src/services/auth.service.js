const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');
const logger = require('../config/logger');
const { logAction } = require('./systemLog.service');

/**
 * Generate JWT tokens
 */
const generateTokens = (payload) => {
  const accessToken = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '1d',
  });
  const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  });
  return { accessToken, refreshToken };
};

/**
 * Login for Admin / Professor
 * username + password (hashed in DB)
 */
const loginUser = async (username, password) => {
  // Get user with role
  const result = await db.query(
    `SELECT u.user_id, u.username, u.password_secure, u.is_active,
            r.role_name,
            COALESCE(s.first_name, p.first_name, 'Admin') as first_name,
            COALESCE(s.last_name, p.last_name, '') as last_name,
            COALESCE(s.student_id, NULL) as student_id,
            COALESCE(p.prof_id, NULL) as prof_id
     FROM users u
     JOIN roles r ON u.role_id = r.role_id
     LEFT JOIN students s ON u.user_id = s.user_id
     LEFT JOIN professors p ON u.user_id = p.user_id
     WHERE u.username = $1`,
    [username]
  );

  if (result.rows.length === 0) {
    throw { statusCode: 401, message: 'Invalid username or password.' };
  }

  const user = result.rows[0];

  if (!user.is_active) {
    throw { statusCode: 403, message: 'Account is deactivated. Please contact admin.' };
  }

  // Check password
  const isMatch = await bcrypt.compare(password, user.password_secure);
  if (!isMatch) {
    throw { statusCode: 401, message: 'Invalid username or password.' };
  }

  // Update last_login
  await db.query(
    'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE user_id = $1',
    [user.user_id]
  );

  const payload = {
    user_id: user.user_id,
    username: user.username,
    role: user.role_name,
    first_name: user.first_name,
    last_name: user.last_name,
    student_id: user.student_id,
    prof_id: user.prof_id,
  };

  const tokens = generateTokens(payload);

  await logAction(user.user_id, `LOGIN via username/password`, 'users', user.user_id);
  logger.info(`User logged in: ${user.username} (${user.role_name})`);

  return {
    ...tokens,
    user: payload,
  };
};

/**
 * Login for Student: username = 13-digit student ID, password = last 6 digits
 */
const loginStudent = async (username, password) => {
  // Student username is 13 digits; password is last 6 digits (hashed in DB)
  const result = await db.query(
    `SELECT u.user_id, u.username, u.password_secure, u.is_active,
            r.role_name,
            s.first_name, s.last_name, s.student_id, s.profile_image
     FROM users u
     JOIN roles r ON u.role_id = r.role_id
     JOIN students s ON u.user_id = s.user_id
     WHERE u.username = $1 AND r.role_name = 'Student'`,
    [username]
  );

  if (result.rows.length === 0) {
    throw { statusCode: 401, message: 'Invalid student ID or password.' };
  }

  const user = result.rows[0];

  if (!user.is_active) {
    throw { statusCode: 403, message: 'Account is deactivated.' };
  }

  const isMatch = await bcrypt.compare(password, user.password_secure);
  if (!isMatch) {
    throw { statusCode: 401, message: 'Invalid student ID or password.' };
  }

  await db.query(
    'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE user_id = $1',
    [user.user_id]
  );

  const payload = {
    user_id: user.user_id,
    username: user.username,
    role: user.role_name,
    first_name: user.first_name,
    last_name: user.last_name,
    student_id: user.student_id,
    profile_image: user.profile_image,
  };

  const tokens = generateTokens(payload);

  await logAction(user.user_id, 'STUDENT_LOGIN', 'users', user.user_id);
  logger.info(`Student logged in: ${user.username}`);

  return { ...tokens, user: payload };
};

/**
 * Refresh access token
 */
const refreshAccessToken = async (refreshToken) => {
  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const { iat, exp, ...payload } = decoded;

    const accessToken = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '1d',
    });

    return { accessToken };
  } catch (error) {
    throw { statusCode: 401, message: 'Invalid or expired refresh token.' };
  }
};

module.exports = { loginUser, loginStudent, refreshAccessToken };
