-- ================================================================
-- UMS Seed Data
-- Run AFTER University_system.sql migration
-- Passwords are bcrypt hashed (cost=10)
-- ================================================================

-- ─── Departments ──────────────────────────────────────────────
INSERT INTO departments (name, location) VALUES
  ('Computer Science', 'Building A, Floor 3'),
  ('Information Technology', 'Building B, Floor 2'),
  ('Mathematics', 'Building C, Floor 1'),
  ('Business Administration', 'Building D, Floor 4'),
  ('Engineering', 'Building E, Floor 2')
ON CONFLICT DO NOTHING;

-- ─── Users: Admin ─────────────────────────────────────────────
-- password: Admin@1234
INSERT INTO users (username, password_secure, email, role_id, is_active) VALUES
  ('admin', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'admin@ums.ac.th', 
   (SELECT role_id FROM roles WHERE role_name = 'Admin'), true)
ON CONFLICT DO NOTHING;

-- ─── Users: Professors ────────────────────────────────────────
-- password: Prof@1234
INSERT INTO users (username, password_secure, email, role_id, is_active) VALUES
  ('prof_somchai', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'somchai@ums.ac.th',
   (SELECT role_id FROM roles WHERE role_name = 'Professor'), true),
  ('prof_wanida', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'wanida@ums.ac.th',
   (SELECT role_id FROM roles WHERE role_name = 'Professor'), true),
  ('prof_anon', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'anon@ums.ac.th',
   (SELECT role_id FROM roles WHERE role_name = 'Professor'), true)
ON CONFLICT DO NOTHING;

-- Professors profile
INSERT INTO professors (user_id, first_name, last_name, dept_id) VALUES
  ((SELECT user_id FROM users WHERE username = 'prof_somchai'), 'สมชาย', 'ใจดี',
   (SELECT dept_id FROM departments WHERE name = 'Computer Science')),
  ((SELECT user_id FROM users WHERE username = 'prof_wanida'), 'วนิดา', 'รักเรียน',
   (SELECT dept_id FROM departments WHERE name = 'Information Technology')),
  ((SELECT user_id FROM users WHERE username = 'prof_anon'), 'อนนท์', 'สุขใจ',
   (SELECT dept_id FROM departments WHERE name = 'Mathematics'))
ON CONFLICT DO NOTHING;

-- ─── Users: Students ──────────────────────────────────────────
-- Student username = 13-digit ID, password = last 6 digits hashed
-- e.g., ID: 6601234567890, password: 567890 → hash below
-- password hash for "567890": $2a$10$YourHashHere
-- NOTE: Generate real hashes with bcrypt before deploying!

-- For demo: password hash of "000001" (last 6 of each student ID)
INSERT INTO users (username, password_secure, email, role_id, is_active) VALUES
  ('6601234567891', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'std001@student.ums.ac.th',
   (SELECT role_id FROM roles WHERE role_name = 'Student'), true),
  ('6601234567892', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'std002@student.ums.ac.th',
   (SELECT role_id FROM roles WHERE role_name = 'Student'), true),
  ('6601234567893', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'std003@student.ums.ac.th',
   (SELECT role_id FROM roles WHERE role_name = 'Student'), true)
ON CONFLICT DO NOTHING;

-- Students profile
INSERT INTO students (user_id, first_name, last_name, enrollment_date) VALUES
  ((SELECT user_id FROM users WHERE username = '6601234567891'), 'สมหญิง', 'ดีมาก', '2023-06-01'),
  ((SELECT user_id FROM users WHERE username = '6601234567892'), 'ประสิทธิ์', 'เก่งมาก', '2023-06-01'),
  ((SELECT user_id FROM users WHERE username = '6601234567893'), 'มานะ', 'ตั้งใจ', '2024-06-01')
ON CONFLICT DO NOTHING;

-- ─── Courses ──────────────────────────────────────────────────
INSERT INTO courses (course_code, title, credits, dept_id) VALUES
  ('CS101', 'Introduction to Programming', 3, (SELECT dept_id FROM departments WHERE name = 'Computer Science')),
  ('CS201', 'Data Structures and Algorithms', 3, (SELECT dept_id FROM departments WHERE name = 'Computer Science')),
  ('CS301', 'Database Systems', 3, (SELECT dept_id FROM departments WHERE name = 'Computer Science')),
  ('CS401', 'Web Application Development', 3, (SELECT dept_id FROM departments WHERE name = 'Computer Science')),
  ('IT101', 'Network Fundamentals', 3, (SELECT dept_id FROM departments WHERE name = 'Information Technology')),
  ('IT201', 'Cybersecurity Basics', 3, (SELECT dept_id FROM departments WHERE name = 'Information Technology')),
  ('MATH101', 'Calculus I', 3, (SELECT dept_id FROM departments WHERE name = 'Mathematics')),
  ('MATH201', 'Linear Algebra', 3, (SELECT dept_id FROM departments WHERE name = 'Mathematics'))
ON CONFLICT DO NOTHING;

-- ─── Class Schedules ──────────────────────────────────────────
INSERT INTO class_schedules (course_id, prof_id, day_of_week, start_time, end_time, room_number) VALUES
  ((SELECT course_id FROM courses WHERE course_code = 'CS101'),
   (SELECT prof_id FROM professors WHERE last_name = 'ใจดี'),
   'Monday', '09:00', '12:00', 'A301'),
  ((SELECT course_id FROM courses WHERE course_code = 'CS201'),
   (SELECT prof_id FROM professors WHERE last_name = 'ใจดี'),
   'Wednesday', '13:00', '16:00', 'A302'),
  ((SELECT course_id FROM courses WHERE course_code = 'CS301'),
   (SELECT prof_id FROM professors WHERE last_name = 'รักเรียน'),
   'Tuesday', '09:00', '12:00', 'B201'),
  ((SELECT course_id FROM courses WHERE course_code = 'IT101'),
   (SELECT prof_id FROM professors WHERE last_name = 'รักเรียน'),
   'Thursday', '13:00', '16:00', 'B202')
ON CONFLICT DO NOTHING;

-- ─── Exam Schedules ───────────────────────────────────────────
INSERT INTO exam_schedules (course_id, exam_type, exam_date, start_time, end_time, room_number) VALUES
  ((SELECT course_id FROM courses WHERE course_code = 'CS101'), 'Midterm', '2024-09-15', '09:00', '12:00', 'HALL-A'),
  ((SELECT course_id FROM courses WHERE course_code = 'CS101'), 'Final',   '2024-11-20', '09:00', '12:00', 'HALL-A'),
  ((SELECT course_id FROM courses WHERE course_code = 'CS201'), 'Midterm', '2024-09-17', '13:00', '16:00', 'HALL-B'),
  ((SELECT course_id FROM courses WHERE course_code = 'CS301'), 'Final',   '2024-11-22', '13:00', '16:00', 'HALL-B')
ON CONFLICT DO NOTHING;

-- ─── Enrollments ──────────────────────────────────────────────
INSERT INTO enrollments (student_id, course_id, semester) VALUES
  ((SELECT student_id FROM students s JOIN users u ON s.user_id = u.user_id WHERE u.username = '6601234567891'),
   (SELECT course_id FROM courses WHERE course_code = 'CS101'), '1/2566'),
  ((SELECT student_id FROM students s JOIN users u ON s.user_id = u.user_id WHERE u.username = '6601234567891'),
   (SELECT course_id FROM courses WHERE course_code = 'CS201'), '1/2566'),
  ((SELECT student_id FROM students s JOIN users u ON s.user_id = u.user_id WHERE u.username = '6601234567892'),
   (SELECT course_id FROM courses WHERE course_code = 'CS101'), '1/2566'),
  ((SELECT student_id FROM students s JOIN users u ON s.user_id = u.user_id WHERE u.username = '6601234567893'),
   (SELECT course_id FROM courses WHERE course_code = 'IT101'), '1/2566')
ON CONFLICT DO NOTHING;

-- ─── Books ────────────────────────────────────────────────────
INSERT INTO books (isbn, title, author, total_copies, available_copies) VALUES
  ('978-0-13-468599-1', 'Clean Code', 'Robert C. Martin', 5, 3),
  ('978-0-13-235088-4', 'The Pragmatic Programmer', 'Andrew Hunt', 3, 2),
  ('978-0-201-63361-0', 'Design Patterns', 'Gang of Four', 4, 4),
  ('978-1-491-95038-0', 'JavaScript: The Good Parts', 'Douglas Crockford', 6, 5),
  ('978-0-596-51774-8', 'Learning Python', 'Mark Lutz', 4, 3),
  ('978-0-13-110362-7', 'The C Programming Language', 'Kernighan & Ritchie', 3, 3)
ON CONFLICT DO NOTHING;

-- ─── Summary ──────────────────────────────────────────────────
-- Test Accounts:
--   Admin    : username=admin,          password=Admin@1234
--   Professor: username=prof_somchai,   password=Prof@1234
--   Student  : username=6601234567891,  password=Admin@1234 (demo, same hash)
-- NOTE: In production, generate proper bcrypt hashes per user!
